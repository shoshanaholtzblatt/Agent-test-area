# Discussion Guide Template

Use this as the study-specific guide attached to or pasted into your Custom GPT.

## Study Setup

**Study name:** [Name]

**Research goal:** [What you are trying to understand]

**Target participant:** [Who qualifies]

**Expected interview length:** [Minutes]

**Stimulus or concept:** [None / screenshot / prototype / concept description]

**Do not ask about:** [Sensitive or out-of-scope topics]

## Opening

1. "Before we start: this is a research interview. Please do not share sensitive personal information. You can skip any question or stop at any time. Is it okay to begin?"
2. "What participant ID should I use for this session, if any?"

## Recent Experience

1. "Tell me about the last time you [did the behavior / had the experience]."
2. "What happened first?"
3. "What did you do next?"
4. "What made you decide to [take action / not take action]?"

## Decision Process

1. "What information did you look for?"
2. "What felt clear?"
3. "What felt unclear?"
4. "What made you feel confident or uncertain?"
5. "Were there any moments where you changed your mind?"

## Pain Points and Workarounds

1. "What was frustrating or harder than expected?"
2. "Did you try any workarounds?"
3. "Was there anything you avoided doing?"
4. "What would have made this easier?"

## Trust, Risk, and Confidence

1. "Was there anything that affected how much you trusted the process?"
2. "What would have made it feel more trustworthy?"
3. "Was there anything you worried might go wrong?"

## Stimulus Reaction

Only ask these after the behavioral section.

1. "Now I am going to show you [stimulus]. What is your first reaction?"
2. "What, if anything, feels useful?"
3. "What, if anything, feels confusing or missing?"
4. "How would this have changed the experience you described earlier?"

## Closing

1. "Is there anything else you think the research team should understand?"
2. "Is there anything I should have asked but did not?"

## Moderator Notes

- Ask one question at a time.
- Prefer "Tell me about the last time..." over "What do you usually..."
- Probe only when an answer is important but under-specified.
- Move on when the participant has already answered clearly.


# Summary Quality Review Prompt

Use this after a pilot interview. Paste the transcript and the structured summary into a separate chat.

```text
You are reviewing an AI-moderated interview summary for research quality.

Compare the transcript against the structured summary.

Check for:
1. Inventions: details in the summary that the participant did not say.
2. Missing evidence: important participant statements not captured in the summary.
3. Over-interpretation: claims that go beyond what the transcript supports.
4. Weak quotes: quotes that are paraphrased but presented as direct quotes.
5. Confidence rating: whether low, medium, or high is justified.
6. Follow-up quality: whether the suggested follow-up questions are grounded in the interview.

Return:
- Overall verdict: pass, revise, or fail
- Highest-risk issue
- Specific corrections to make
- Revised structured summary if needed

Transcript:
[paste transcript]

Structured summary:
[paste summary]
```


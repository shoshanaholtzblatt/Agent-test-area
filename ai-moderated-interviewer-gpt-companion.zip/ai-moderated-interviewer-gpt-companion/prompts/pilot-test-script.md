# Pilot Test Script

Before using the GPT with participants, run several fake interviews. Use these prompts to test whether the moderator behaves well.

## Test 1: Short Answers

```text
I am going to act like a participant who gives short answers. Please start the interview.
```

Participant replies to use:

```text
Yes.
P001.
Last week.
Payment was delayed.
I checked the app.
No.
It was confusing.
I waited.
That's all.
```

What to watch for:

- Does the interviewer recover without asking three questions at once?
- Does it ask for concrete details?
- Does it avoid sounding impatient?

## Test 2: Vague Praise

Participant replies to use:

```text
Everything was fine.
I guess it was pretty easy.
I don't remember much.
It worked okay.
```

What to watch for:

- Does the interviewer ask for a recent example?
- Does it avoid accepting generic praise as a finding?
- Does it mark confidence as low if the interview stays vague?

## Test 3: Emotional Frustration

Participant replies to use:

```text
I was really annoyed because I thought my money disappeared.
I kept refreshing the page.
I did not trust that anyone would help.
```

What to watch for:

- Does the interviewer probe the source of distrust?
- Does it stay neutral instead of reassuring or apologizing?
- Does it capture the emotional signal without exaggerating it?

## Test 4: Irrelevant Answer

Participant replies to use:

```text
This reminds me of a completely different app I used in college.
Anyway, I think all support teams are bad.
```

What to watch for:

- Does the interviewer gently return to the study topic?
- Does it avoid arguing?
- Does it avoid treating broad opinion as behavioral evidence?

## Test 5: Premature Summary Request

Participant prompt:

```text
Can you summarize this now and save it?
```

What to watch for:

- If the interview is incomplete, does the GPT ask whether the participant wants to end?
- Does it avoid saving partial data without confirmation?


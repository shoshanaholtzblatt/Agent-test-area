# Example Research Brief: Payment Support Experience Study

## Study Goal

Understand how people decide whether to contact customer support when they have a payment issue.

## Target Participant

People who recently had a delayed, failed, missing, or unclear payment in a digital product or service.

## Main Research Questions

- What do people try before contacting support?
- What makes a payment issue feel urgent?
- What makes the process feel trustworthy or untrustworthy?
- What information do people need before deciding to contact support?
- What would make the experience easier?

## Topics to Cover

- Recent payment issue
- First reaction
- Steps taken before support
- Decision to contact or avoid support
- Trust and uncertainty
- Workarounds
- Desired improvements

## Avoid

- Do not ask for financial account numbers.
- Do not ask for exact dollar amounts unless volunteered.
- Do not collect personally identifying information.
- Do not give advice about financial, legal, or account-specific issues.
- Do not troubleshoot the participant's real payment problem.

## Summary Requirements

The final summary should include participant context, key behaviors, pain points, decision drivers, workarounds, notable quotes, unmet needs, follow-up questions, and interpretation confidence.


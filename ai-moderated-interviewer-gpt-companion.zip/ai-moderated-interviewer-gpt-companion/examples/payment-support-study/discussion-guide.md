# Example Discussion Guide: Payment Support Experience Study

## Opening

1. "Before we start: this is a research interview. Please do not share sensitive personal information. You can skip any question or stop at any time. Is it okay to begin?"
2. "What participant ID should I use for this session, if any?"

## Recent Experience

1. "Tell me about the last time you had a payment issue and considered contacting support."
2. "What happened first?"
3. "What did you try before contacting support?"
4. "What made you decide whether to contact support?"

## Decision Criteria

1. "What information were you looking for?"
2. "What made the issue feel urgent or not urgent?"
3. "Was there anything that made you feel more or less confident?"

## Pain Points and Workarounds

1. "What felt confusing or frustrating?"
2. "Did you try any workarounds?"
3. "What would have made the process easier?"

## Trust

1. "Was there anything that affected how much you trusted the process?"
2. "What would have made it feel more trustworthy?"

## Closing

1. "Is there anything else the research team should understand?"
2. "Is there anything I should have asked but did not?"


# Sample Participant Run

This is a fictional pilot run for testing the interviewer behavior and summary format.

## Transcript

**Interviewer:** Before we start: this is a research interview. Please do not share sensitive personal information. You can skip any question or stop at any time. Is it okay to begin?

**Participant:** Yes.

**Interviewer:** What participant ID should I use for this session, if any?

**Participant:** P001.

**Interviewer:** Tell me about the last time you had a payment issue and considered contacting support.

**Participant:** Last month I paid a contractor through an app, and the payment said pending for a long time. I was not sure if it had actually gone through.

**Interviewer:** What did you do first?

**Participant:** I checked the transaction history, then checked my bank app. The bank showed something, but the app still said pending.

**Interviewer:** What made you consider contacting support?

**Participant:** I did not know if the contractor would get paid. It was time-sensitive, and I did not want to pay twice.

**Interviewer:** What felt unclear?

**Participant:** The status. Pending could mean a lot of things. It did not say whether anyone needed to do anything.

**Interviewer:** Did you try any workarounds before contacting support?

**Participant:** I waited a few hours and texted the contractor to ask if they saw anything. Then I searched the help center.

**Interviewer:** Was there anything that affected how much you trusted the process?

**Participant:** I did not trust it because there was no timeline. I did not know if anyone would actually look at it.

**Interviewer:** What would have made it feel more trustworthy?

**Participant:** A clear status, like "we are checking this" or "this usually resolves in 24 hours." Also maybe a confirmation that opening a ticket would not duplicate the payment.

**Interviewer:** Is there anything else the research team should understand?

**Participant:** Payment issues feel more stressful than normal support questions because you worry about making it worse.

## Expected Notes

The interviewer asks one question at a time, stays neutral, and probes confusion, trust, urgency, and workarounds without giving advice.


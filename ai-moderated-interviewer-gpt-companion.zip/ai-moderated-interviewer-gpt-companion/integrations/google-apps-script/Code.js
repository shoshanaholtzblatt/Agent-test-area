const SHEET_NAME = "Responses";

function doPost(e) {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
    if (!sheet) {
      return jsonResponse({ status: "error", message: `Missing sheet: ${SHEET_NAME}` }, 500);
    }

    const data = JSON.parse(e.postData.contents || "{}");

    sheet.appendRow([
      new Date(),
      data.participant_id || "",
      data.study_name || "",
      data.participant_context || "",
      JSON.stringify(data.key_behaviors || []),
      JSON.stringify(data.pain_points || []),
      JSON.stringify(data.decision_drivers || []),
      JSON.stringify(data.workarounds || []),
      JSON.stringify(data.notable_quotes || []),
      JSON.stringify(data.unmet_needs || []),
      JSON.stringify(data.follow_up_questions || []),
      data.interpretation_confidence || "",
      JSON.stringify(data)
    ]);

    return jsonResponse({ status: "success" }, 200);
  } catch (error) {
    return jsonResponse({ status: "error", message: String(error) }, 500);
  }
}

function jsonResponse(payload, statusCode) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}


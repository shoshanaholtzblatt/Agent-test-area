# AI-Moderated Interviewer with a Custom GPT
by: Saeideh Bakhshi
saeideh.com

Companion materials for the blog post: **How to Build a Simple AI-Moderated Interviewer with a Custom GPT**.

This repo is a lightweight starter kit for prototyping AI-moderated research before investing in a dedicated platform. It is designed for early learning, not for sensitive, regulated, client-facing, or fully automated research.

## What is included


- `prompts/custom-gpt-instructions.md` - copy-paste Custom GPT instruction set.
- `prompts/discussion-guide-template.md` - reusable study guide template.
- `prompts/pilot-test-script.md` - prompts for stress-testing the interviewer before launch.
- `prompts/summary-quality-review.md` - review prompt for checking whether summaries are faithful.
- `examples/payment-support-study/` - worked example study with brief, guide, sample run, and expected structured summary.
- `integrations/google-apps-script/Code.js` - simple Apps Script endpoint that appends summaries to a Google Sheet.
- `integrations/openapi/gpt-action-schema.yaml` - example OpenAPI schema for a GPT action.
- `integrations/sheets-columns.csv` - suggested Google Sheet column headers.
- `checklists/setup-checklist.md` - setup and testing checklist.
- `checklists/ethics-privacy-checklist.md` - basic research-risk checklist.

## Minimal prototype flow

1. Create a Custom GPT.
2. Paste in the interviewer instructions.
3. Add your research brief and discussion guide as knowledge or pasted context.
4. Create a Google Sheet with the suggested columns.
5. Attach the Apps Script endpoint.
6. Add the OpenAPI schema as a GPT action.
7. Test in Preview before using it with participants.

OpenAI's current GPT help docs describe actions as connections to external APIs defined by an OpenAPI schema. They also note that a GPT can use apps or actions, but not both at the same time. For setup details, see OpenAI's help pages on [configuring actions in GPTs](https://help.openai.com/en/articles/9442513-configuring-actions-in-gpts) and [creating and editing GPTs](https://help.openai.com/en/articles/8554397-creating-and-editing-gpts).

## Important limits

This starter kit does not handle recruiting, participant identity, consent management, secure transcript storage, automated redaction, sampling logic, quotas, randomization, or formal analysis. Treat it as a prototype for learning whether AI moderation is worth deeper investment.

For real studies, especially sensitive or publishable research, review your privacy, security, consent, legal, and data-retention requirements before collecting participant data.


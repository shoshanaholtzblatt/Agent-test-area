# Ethics and Privacy Checklist

This prototype is intentionally lightweight. Use this checklist before collecting real participant data.

## Participant Protection

- Participants know they are interacting with an AI interviewer.
- Participants know they can skip questions or stop at any time.
- Participants are told not to share sensitive personal information.
- The study avoids collecting unnecessary personally identifying information.
- The interviewer does not ask for account numbers, passwords, exact financial details, medical details, legal details, or other sensitive information unless the study has formal controls for that data.

## Consent and Data Use

- The consent language matches how the data will actually be used.
- Participants understand whether transcripts, summaries, or both are stored.
- Participants understand who can access the data.
- Participants understand how long data will be retained.

## Data Handling

- The Google Sheet is access-restricted.
- The Apps Script deployment is not shared publicly beyond what is needed.
- Raw JSON is reviewed before analysis.
- Data is deleted when no longer needed.
- Sensitive studies use a more secure backend instead of this prototype.

## Research Quality

- The GPT was pilot-tested with realistic participant behavior.
- A human reviewed the first several summaries against transcripts.
- The team has agreed on what counts as evidence.
- The team does not treat AI summaries as final analysis without human review.
- Confidence ratings are used to flag weak interviews, not to make the findings look more certain.


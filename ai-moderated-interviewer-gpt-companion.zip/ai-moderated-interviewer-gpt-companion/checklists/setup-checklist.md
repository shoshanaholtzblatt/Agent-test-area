# Setup Checklist

## Custom GPT

- Create a new GPT in ChatGPT.
- Give it a clear name, such as "AI Research Interviewer".
- Paste `prompts/custom-gpt-instructions.md` into Instructions.
- Add your research brief and discussion guide.
- Add realistic conversation starters.
- Disable capabilities you do not need.

## Google Sheet

- Create a Google Sheet.
- Add a tab named `Responses`.
- Paste the headers from `integrations/sheets-columns.csv`.
- Open Extensions > Apps Script.
- Paste the code from `integrations/google-apps-script/Code.js`.
- Deploy as a web app.
- Copy the deployment URL.

## GPT Action

- In the GPT editor, go to Actions.
- Create a new action.
- Paste `integrations/openapi/gpt-action-schema.yaml`.
- Replace `YOUR_SCRIPT_ID` or the server URL with your deployed Apps Script URL.
- Use no authentication only for private prototypes with non-sensitive fake or pilot data.
- Test the action in Preview.

## Pilot Tests

- Run short-answer, vague-answer, emotional-answer, irrelevant-answer, and premature-summary tests.
- Confirm the GPT asks one question at a time.
- Confirm it does not save anything before the interview is complete.
- Confirm it does not invent participant details.
- Confirm the Google Sheet receives the expected fields.
- Review at least three pilot summaries manually before using the setup with real participants.


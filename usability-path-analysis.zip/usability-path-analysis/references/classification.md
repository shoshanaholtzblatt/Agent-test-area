# Frame classification

Classification is the only LLM-judgment stage in the pipeline, so its discipline determines path quality. The task per frame is: **which inventory screen is this?** — never "describe this frame."

## Setup per session

1. Read `inventory.json` in full — IDs, distinguishing features, confusable pairs.
2. View every reference image in `refs/` once, before classifying any frames, so the visual anchors are loaded.
3. Load the task window's `task_prompt` and `transcript_excerpt` from `task_windows.json`.

## Batching

- Process frames **strictly in timestamp order** within a task window.
- Batch size: 8–12 frames per pass works well; drop to 4–6 if screens are dense or accuracy is suffering. Sequential context helps — knowing frame N was `transfer-amount` makes frame N+1 easier — so never shuffle or parallelize within a window.
- At the start of each batch after the first, restate the last 2–3 classifications from the previous batch as context ("previous frames ended on transfer-confirm at t=384.2").

## Per-frame output schema

Append one record per frame to `classifications/<session>_<task>.json`:

```json
{
  "session_id": "P07",
  "task_id": "task-1",
  "frames": [
    {
      "timestamp": 340.1,
      "screen_id": "transfer-amount",
      "confidence": "high",
      "evidence": "Header 'Transfer money', centered amount input visible",
      "state_notes": "amount field populated with 50.00"
    }
  ]
}
```

Field rules:
- **screen_id** — must be an inventory ID, or `unknown`, or `transitional`. No freeform IDs, ever; an ID not in the inventory breaks path assembly and hides an inventory gap that should be surfaced instead.
- **confidence** — `high` (multiple distinguishing features match), `medium` (partial match or minor occlusion), `low` (plausible but weak). Confidence flows into the timeline for review flagging, so be honest — a `low` that's right is more useful than a `high` that's wrong.
- **evidence** — the specific visible elements supporting the match. Cite text content where legible; it's the strongest signal in compressed frames.
- **state_notes** — modal open, error banner, scroll position, form fill state, loading spinner. Empty string if nothing notable.

## Rules that protect path quality

- **Never force-fit.** If a frame doesn't clearly match an inventory screen, it is `unknown`. A confident wrong label corrupts the assembled path silently; `unknown` produces a visible review gap.
- **`transitional`** is for mid-navigation frames: partial page loads, animation midpoints, white flashes. Distinct from `unknown` (which means "a settled screen I can't identify").
- **Recurring unknowns are inventory gaps.** If the same unfamiliar screen appears as `unknown` across several frames or sessions, stop and tell the user — it likely needs an inventory entry (see screen-inventory.md, states vs. screens).
- **Infer actions from state deltas, not cursors.** "Modal appeared between t=340.1 and t=342.6" is reliable; "user clicked the Save button" from a cursor position usually is not. Phrase state_notes accordingly.
- **Use the task context, don't be captured by it.** The task prompt says which flow is *intended*; participants get lost. If the frame shows the settings page during a transfer task, classify it as the settings page.
- **Confusable pairs get extra care.** When a frame could be either member of a `confusable_with` pair, apply the inventory's disambiguation rule explicitly in the evidence field.

# Screen inventory setup

The inventory is the ground truth every frame is classified against. Build it once per study, before any video work.

## inventory.json schema

```json
{
  "study": "Q3 transfer flow usability",
  "screens": [
    {
      "id": "transfer-amount",
      "name": "Transfer — enter amount",
      "ref_image": "refs/transfer-amount.png",
      "distinguishing_features": [
        "Header reads 'Transfer money'",
        "Large amount input field centered",
        "'Continue' button bottom right"
      ],
      "confusable_with": ["transfer-confirm"],
      "disambiguation": "Confirm screen shows a summary card, not an input field"
    }
  ],
  "expected_paths": {
    "task-1": [
      ["home", "transfer-amount", "transfer-confirm", "transfer-done"]
    ]
  }
}
```

Notes on fields:
- **id** — stable slug; this is what appears in all path data. Never rename mid-study.
- **distinguishing_features** — text anchors matter as much as the reference image. Frames are compressed; the visible copy ("Confirm transfer", "Edit amount") is often the most reliable match signal.
- **confusable_with / disambiguation** — fill these in for any screens that look similar (list vs. detail, step 1 vs. step 2 of a wizard). Classification errors cluster on confusable pairs; explicit disambiguation rules fix most of them.
- **expected_paths** — one or more acceptable sequences per task. Multiple entries per task are fine (alternate valid routes). Omit for exploratory tasks with no designed path; the assembler then skips off-path detection.

## Source option 1: Figma MCP

If a Figma MCP is connected:
1. Ask the user for the file/prototype containing the tested flows.
2. Pull the frames/screens for the tested flow; use node names as screen IDs (slugified).
3. Export each screen image into `refs/`.
4. If the file has prototype connections, translate them into `expected_paths` — the prototype wiring *is* the intended path graph.

**Domain-gap caveat**: Figma exports are clean renders; captured video frames are compressed and may show real data, scroll positions, and browser chrome. If classification accuracy is poor with Figma refs, keep the Figma-derived IDs, names, and expected paths, but replace `refs/` images with real captured frames (see option 3). Flag this tradeoff to the user up front when they choose Figma as the source.

## Source option 2: Manual screenshots

The user supplies captures of each screen (from the live product, a staging environment, or prior sessions). Ask them to name each one; build inventory.json interactively — for each image, propose distinguishing features from what is visible and confirm with the user. Build `expected_paths` by asking the user to describe the intended route per task.

## Source option 3: Bootstrap from video frames

When no inventory exists:
1. Pick one representative session. Run `extract_frames.py` on its full task windows at the default threshold.
2. Review the extracted frames in timestamp order and group visually distinct screens (ignore transient states like spinners for now).
3. Present one exemplar per group to the user; have them name it and confirm groupings.
4. Copy exemplars into `refs/`, write inventory.json.
5. Ask the user for expected paths per task, or derive a draft from the task prompts and confirm.

This option guarantees zero domain gap and is the right fallback whenever options 1–2 produce poor classification accuracy.

## Handling states vs. screens

Decide with the user how granular the inventory should be:
- **Screen-level** (default): modals, error banners, and filled forms are `state_notes` on the parent screen, not separate inventory entries.
- **State-level**: if the study specifically cares about a modal or error state (e.g., "do participants see the overdraft warning?"), promote it to its own inventory entry with its own ID.

Screen-level keeps paths readable; state-level makes specific states countable across sessions. Mixed is fine — promote only the states the research questions care about.

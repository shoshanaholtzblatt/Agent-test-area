# Deliverables

Every analysis run produces both per-session path data and, once multiple sessions exist, a cross-session comparison report.

## 1. Per-session path data

`assemble_path.py` produces this automatically. Per session+task:
- `paths/<session>_<task>.json` — visits with dwell times, transitions, revisits, backtracks, off-path transitions, review gaps.
- `paths/<session>_<task>.md` (with `--timeline`) — human-readable timeline.

After assembly, review each timeline and add a short researcher-facing summary at the top (3–5 sentences): the route taken, total time in task window, notable friction signals (long dwells, backtracks, off-path excursions), and any review gaps that need human eyes on the video. Keep it descriptive — what happened, when — and leave interpretation to the cross-session report.

## 2. Cross-session comparison report

Input: `report/aggregate.json` from `assemble_path.py --aggregate`.

ALWAYS use this structure:

```markdown
# Path analysis — [study name]

## Method summary
[Sessions analyzed, extraction settings from config.json, inventory source,
 known limitations: unknown-gap totals, any sessions excluded and why]

## Per-task findings
### [Task name]
**Intended path:** [from expected_paths, or "exploratory — no designed path"]
**Path variants observed:** [table: path → n sessions]
**Deviations:** [common off-path transitions, where in the flow they occur]
**Dwell patterns:** [screens with high mean or outlier dwell; name the sessions]
**Backtracking:** [which sessions, at which screens]

## Cross-task observations
[Patterns spanning tasks: screens that cause trouble everywhere,
 participants who struggled across the board]

## Open questions for review
[Every claim here must trace to path data or transcript evidence.
 Behavioral "why" hypotheses go here as questions, not findings —
 e.g., "P03 and P07 both backtracked at transfer-confirm; the transcript
 shows P07 asking about fees at that moment — worth reviewing whether
 the fee disclosure is the trigger."]
```

Grounding rules for the report:
- Quantitative claims (counts, dwell times, variant frequencies) come from aggregate.json only — never estimated.
- Behavioral interpretation ("participants hesitated because...") is not supported by silent screen captures alone. Pair path evidence with transcript quotes, or frame it as an open question.
- Report unknown/transitional gap totals honestly in the method summary. If gaps exceed roughly 10% of any task window, say the path data for that task is partial and flag it for manual review rather than smoothing over it.
- Small-n language: with typical usability sample sizes (5–12 sessions), report counts ("4 of 7 sessions"), not percentages.

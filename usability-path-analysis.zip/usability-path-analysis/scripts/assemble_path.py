#!/usr/bin/env python3
"""Assemble a navigation path from frame classifications. Deterministic — no
LLM judgment — so results are auditable and re-runnable.

Single session:
  python3 assemble_path.py classifications/P07_task-1.json \
      --inventory screen-inventory/inventory.json \
      --out paths/P07_task-1.json --timeline

Aggregate across sessions (after assembling each):
  python3 assemble_path.py --aggregate paths/ --out report/

Input classification schema (one file per session+task):
{
  "session_id": "P07", "task_id": "task-1",
  "frames": [
    {"timestamp": 312.4, "screen_id": "home", "confidence": "high",
     "evidence": "...", "state_notes": ""}
  ]
}

Inventory may contain expected paths per task:
  "expected_paths": {"task-1": [["home","transfer-amount","transfer-confirm","transfer-done"]]}
"""

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path


def collapse_visits(frames):
    """Collapse consecutive same-screen frames into visits with dwell time."""
    visits = []
    for f in sorted(frames, key=lambda x: x["timestamp"]):
        sid = f.get("screen_id", "unknown")
        if visits and visits[-1]["screen_id"] == sid:
            v = visits[-1]
            v["end_s"] = f["timestamp"]
            v["frame_count"] += 1
            if f.get("confidence") == "low":
                v["low_confidence_frames"] += 1
            if f.get("state_notes"):
                v["state_notes"].append(
                    {"t": f["timestamp"], "note": f["state_notes"]})
        else:
            visits.append({
                "screen_id": sid,
                "start_s": f["timestamp"],
                "end_s": f["timestamp"],
                "frame_count": 1,
                "low_confidence_frames": 1 if f.get("confidence") == "low" else 0,
                "state_notes": ([{"t": f["timestamp"], "note": f["state_notes"]}]
                                if f.get("state_notes") else []),
            })
    # Dwell = this visit's start to the NEXT visit's start. With
    # change-detection extraction, no new frames arrive while a screen is
    # static, so a visit's own frame span understates time on screen.
    for i, v in enumerate(visits):
        if i + 1 < len(visits):
            v["dwell_s"] = round(visits[i + 1]["start_s"] - v["start_s"], 3)
        else:
            # Last visit: only its own frame span is known (a lower bound,
            # since the task window may extend past the final frame).
            v["dwell_s"] = round(v["end_s"] - v["start_s"], 3)
            v["dwell_truncated"] = True
    return visits


def analyze(visits, expected=None):
    """Compute transitions, revisits, backtracks, and off-path steps."""
    seq = [v["screen_id"] for v in visits]
    transitions = [{"from": a, "to": b,
                    "t": visits[i + 1]["start_s"]}
                   for i, (a, b) in enumerate(zip(seq, seq[1:]))]

    seen, revisits = set(), []
    for i, s in enumerate(seq):
        if s in seen and s not in ("unknown", "transitional"):
            revisits.append({"screen_id": s, "visit_index": i,
                             "t": visits[i]["start_s"]})
        seen.add(s)

    # Backtrack: returning to the immediately-previous distinct screen (A→B→A)
    backtracks = [{"pattern": f"{seq[i]}→{seq[i+1]}→{seq[i+2]}",
                   "t": visits[i + 2]["start_s"]}
                  for i in range(len(seq) - 2)
                  if seq[i] == seq[i + 2] and seq[i] != seq[i + 1]
                  and "unknown" not in (seq[i], seq[i + 1])
                  and "transitional" not in (seq[i], seq[i + 1])]

    off_path = []
    if expected:
        allowed = set()
        for path in expected:
            allowed.update(zip(path, path[1:]))
        for tr in transitions:
            pair = (tr["from"], tr["to"])
            if ("unknown" in pair or "transitional" in pair):
                continue
            if pair not in allowed:
                off_path.append(tr)

    gaps = [{"start_s": v["start_s"], "end_s": v["end_s"],
             "dwell_s": v["dwell_s"]}
            for v in visits if v["screen_id"] in ("unknown", "transitional")]

    return {"sequence": seq, "transitions": transitions,
            "revisits": revisits, "backtracks": backtracks,
            "off_path_transitions": off_path, "review_gaps": gaps}


def write_timeline(path_data, out_path):
    lines = [f"# Path timeline — {path_data['session_id']} / {path_data['task_id']}", ""]
    for v in path_data["visits"]:
        flag = ""
        if v["screen_id"] in ("unknown", "transitional"):
            flag = " ⚠️ review"
        elif v["low_confidence_frames"]:
            flag = f" (low-confidence frames: {v['low_confidence_frames']})"
        lines.append(f"- **{v['start_s']:.1f}s → {v['end_s']:.1f}s** "
                     f"({v['dwell_s']:.1f}s dwell) — `{v['screen_id']}`{flag}")
        for n in v["state_notes"]:
            lines.append(f"  - {n['t']:.1f}s: {n['note']}")
    a = path_data["analysis"]
    if a["backtracks"]:
        lines += ["", "## Backtracks"] + \
                 [f"- {b['t']:.1f}s: {b['pattern']}" for b in a["backtracks"]]
    if a["off_path_transitions"]:
        lines += ["", "## Off-path transitions"] + \
                 [f"- {t['t']:.1f}s: {t['from']} → {t['to']}"
                  for t in a["off_path_transitions"]]
    if a["review_gaps"]:
        lines += ["", "## Gaps needing review (unknown/transitional)"] + \
                 [f"- {g['start_s']:.1f}s → {g['end_s']:.1f}s"
                  for g in a["review_gaps"]]
    out_path.write_text("\n".join(lines) + "\n")


def assemble_one(cls_path, inventory_path, out_path, timeline):
    data = json.loads(cls_path.read_text())
    expected = None
    if inventory_path and inventory_path.exists():
        inv = json.loads(inventory_path.read_text())
        expected = inv.get("expected_paths", {}).get(data.get("task_id"))

    visits = collapse_visits(data["frames"])
    result = {
        "session_id": data.get("session_id", "unknown"),
        "task_id": data.get("task_id", "unknown"),
        "visits": visits,
        "analysis": analyze(visits, expected),
        "expected_path_available": expected is not None,
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2))
    print(f"Wrote {out_path}")
    if timeline:
        tl = out_path.with_suffix(".md")
        write_timeline(result, tl)
        print(f"Wrote {tl}")


def aggregate(paths_dir, out_dir):
    out_dir.mkdir(parents=True, exist_ok=True)
    by_task = defaultdict(list)
    for p in sorted(paths_dir.glob("*.json")):
        d = json.loads(p.read_text())
        by_task[d["task_id"]].append(d)

    report = {}
    for task, sessions in by_task.items():
        variants = Counter()
        deviation_points = Counter()
        dwell = defaultdict(list)
        backtrack_sessions = []
        for s in sessions:
            seq = [x for x in s["analysis"]["sequence"]
                   if x not in ("unknown", "transitional")]
            # collapse repeats introduced by removing unknowns
            dedup = [seq[0]] if seq else []
            for x in seq[1:]:
                if x != dedup[-1]:
                    dedup.append(x)
            variants[" → ".join(dedup)] += 1
            for t in s["analysis"]["off_path_transitions"]:
                deviation_points[f"{t['from']} → {t['to']}"] += 1
            for v in s["visits"]:
                if v["screen_id"] not in ("unknown", "transitional"):
                    dwell[v["screen_id"]].append(v["dwell_s"])
            if s["analysis"]["backtracks"]:
                backtrack_sessions.append(s["session_id"])

        report[task] = {
            "n_sessions": len(sessions),
            "path_variants": [{"path": p, "count": c}
                              for p, c in variants.most_common()],
            "common_deviations": [{"transition": t, "count": c}
                                  for t, c in deviation_points.most_common()],
            "dwell_by_screen": {
                k: {"mean_s": round(sum(v) / len(v), 1),
                    "max_s": round(max(v), 1), "n": len(v)}
                for k, v in sorted(dwell.items())},
            "sessions_with_backtracks": backtrack_sessions,
        }

    out = out_dir / "aggregate.json"
    out.write_text(json.dumps(report, indent=2))
    print(f"Wrote {out}")
    print("Use references/outputs.md report structure to write the "
          "cross-session narrative from this aggregate.")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("classification", nargs="?", type=Path,
                    help="classification JSON for one session+task")
    ap.add_argument("--inventory", type=Path,
                    help="inventory.json (for expected-path diffing)")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--timeline", action="store_true",
                    help="also write a Markdown timeline next to the JSON")
    ap.add_argument("--aggregate", type=Path,
                    help="directory of assembled path JSONs to aggregate")
    args = ap.parse_args()

    if args.aggregate:
        aggregate(args.aggregate, args.out)
    elif args.classification:
        assemble_one(args.classification, args.inventory, args.out, args.timeline)
    else:
        sys.exit("Provide a classification file or --aggregate DIR")


if __name__ == "__main__":
    main()

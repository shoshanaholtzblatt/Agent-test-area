#!/usr/bin/env python3
"""Extract frames from a usability screen-share recording.

Default mode ("diff") does change detection in two passes:
  1. Sample small thumbnails at --sample-fps across each task window.
  2. Compute mean absolute RGB difference between consecutive thumbnails;
     timestamps whose diff exceeds --threshold are kept, then full-resolution
     PNGs are grabbed at those timestamps.

This is deterministic and channel-aware (a pure color change registers even
at equal luminance), unlike ffmpeg's built-in scene filter, which can score
some real changes at zero. Timestamps are preserved in filenames and in a
manifest because dwell-time analysis depends on them.

Usage:
  python3 extract_frames.py VIDEO.mp4 --windows task_windows.json --out frames/
  python3 extract_frames.py VIDEO.mp4 --windows task_windows.json --out frames/ \
      --sample-fps 4 --threshold 3.0
  python3 extract_frames.py VIDEO.mp4 --start 312.4 --end 498.0 --task-id task-1 --out frames/
  python3 extract_frames.py VIDEO.mp4 --windows w.json --out frames/ --mode fps --fps 0.5

Modes:
  diff (default) : keep frames where RGB change vs. previous sample > threshold
  fps            : keep every sample (fixed rate = --sample-fps)

Tuning (diff mode):
  --sample-fps : temporal resolution — how often the screen is checked.
                 2.0 is a good default; raise for fast interactions.
  --threshold  : mean absolute RGB difference (0-255 scale) required to keep
                 a frame. 2.0 default. Lower catches subtle changes (partial
                 page updates); higher ignores cursor blinks and video noise.

Both modes always capture bookend frames (first + last sample of each
window) so a window that opens mid-screen still has a starting state.
"""

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image


def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def probe_duration(video):
    r = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(video)])
    try:
        return float(r.stdout.strip())
    except ValueError:
        sys.exit(f"Could not probe video duration: {r.stderr.strip()}")


def sample_thumbnails(video, start, end, fps, tmpdir):
    """Extract small RGB thumbnails at a fixed rate. Returns [(t, path)]."""
    pattern = str(Path(tmpdir) / "thumb_%06d.png")
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
           "-ss", f"{start:.3f}", "-to", f"{end:.3f}", "-i", str(video),
           "-vf", f"fps={fps},scale=160:-2", pattern]
    r = run(cmd)
    if r.returncode != 0:
        sys.exit(f"Thumbnail pass failed: {r.stderr.strip()}")
    thumbs = sorted(Path(tmpdir).glob("thumb_*.png"))
    # Frame i (1-indexed) is sampled at start + (i-1)/fps
    return [(start + i / fps, p) for i, p in enumerate(thumbs)]


def mean_abs_diff(img_a, img_b):
    """Mean absolute per-pixel RGB difference, 0-255 scale."""
    a = img_a.convert("RGB")
    b = img_b.convert("RGB")
    if a.size != b.size:
        b = b.resize(a.size)
    pa, pb = a.tobytes(), b.tobytes()
    n = len(pa)
    return sum(abs(pa[i] - pb[i]) for i in range(0, n, 7)) / (n / 7)


def select_change_times(samples, threshold):
    """Return timestamps where the frame changed vs. the previous sample."""
    keep = []
    prev_img = None
    for t, path in samples:
        img = Image.open(path)
        if prev_img is not None:
            if mean_abs_diff(prev_img, img) > threshold:
                keep.append(t)
        prev_img = img
    return keep


def grab_frame(video, t, out_path):
    """Extract a single full-resolution PNG at timestamp t."""
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
           "-ss", f"{t:.3f}", "-i", str(video),
           "-frames:v", "1", str(out_path)]
    r = run(cmd)
    return r.returncode == 0 and out_path.exists()


def dedupe(times, min_gap=0.25):
    kept = []
    for t in sorted(set(times)):
        if not kept or t - kept[-1] >= min_gap:
            kept.append(t)
    return kept


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video", type=Path)
    ap.add_argument("--windows", type=Path,
                    help="task_windows.json with {windows:[{task_id,start_s,end_s}]}")
    ap.add_argument("--start", type=float, help="single-window start (seconds)")
    ap.add_argument("--end", type=float, help="single-window end (seconds)")
    ap.add_argument("--task-id", default="task", help="task id for single-window mode")
    ap.add_argument("--out", type=Path, required=True, help="output directory")
    ap.add_argument("--mode", choices=["diff", "fps"], default="diff")
    ap.add_argument("--sample-fps", type=float, default=2.0,
                    help="sampling rate for change detection (or output rate in fps mode)")
    ap.add_argument("--threshold", type=float, default=2.0,
                    help="mean abs RGB diff (0-255) to keep a frame (diff mode)")
    ap.add_argument("--fps", type=float, default=None,
                    help="alias for --sample-fps in fps mode")
    ap.add_argument("--min-gap", type=float, default=0.25,
                    help="minimum seconds between captured frames")
    args = ap.parse_args()

    if not args.video.exists():
        sys.exit(f"Video not found: {args.video}")
    if args.fps:
        args.sample_fps = args.fps

    duration = probe_duration(args.video)

    if args.windows:
        data = json.loads(args.windows.read_text())
        windows = [(w["task_id"], float(w["start_s"]), float(w["end_s"]))
                   for w in data["windows"]]
    elif args.start is not None and args.end is not None:
        windows = [(args.task_id, args.start, args.end)]
    else:
        windows = [("full", 0.0, duration)]

    args.out.mkdir(parents=True, exist_ok=True)
    manifest = {"video": str(args.video), "mode": args.mode,
                "sample_fps": args.sample_fps,
                "threshold": args.threshold if args.mode == "diff" else None,
                "windows": []}

    for task_id, start, end in windows:
        end = min(end, duration)
        if start >= end:
            print(f"[skip] {task_id}: invalid window {start}-{end}", file=sys.stderr)
            continue

        tmpdir = tempfile.mkdtemp(prefix="thumbs_")
        try:
            samples = sample_thumbnails(args.video, start, end,
                                        args.sample_fps, tmpdir)
            if not samples:
                print(f"[warn] {task_id}: no samples extracted", file=sys.stderr)
                continue
            if args.mode == "diff":
                times = select_change_times(samples, args.threshold)
            else:
                times = [t for t, _ in samples]
            # Bookends: always include window start and end states.
            times = dedupe([samples[0][0]] + times + [samples[-1][0]],
                           args.min_gap)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

        frames = []
        for t in times:
            name = f"{task_id}_t{t:09.3f}.png"
            path = args.out / name
            if grab_frame(args.video, t, path):
                frames.append({"file": name, "t": round(t, 3)})
            else:
                print(f"[warn] failed to grab frame at t={t:.3f}", file=sys.stderr)

        manifest["windows"].append({
            "task_id": task_id, "start_s": start, "end_s": end,
            "samples_checked": len(samples),
            "frame_count": len(frames), "frames": frames})
        print(f"{task_id}: {len(frames)} frames kept from {len(samples)} samples "
              f"({(end - start):.0f}s window, {args.mode} mode)")

    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"Manifest written to {args.out / 'manifest.json'}")


if __name__ == "__main__":
    main()
